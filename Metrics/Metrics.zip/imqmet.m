function [quality, quality_map] = imqmet(ims, imf, block_size, cedge)
%imqmet.m, v 0.2 2004/04/19
%===========================================================================
%               Eduardo Fernandez Canga - University of Bristol
%
%                        Copyright (c) 2004
%===========================================================================
%     [q, q_map] = imqind(ims, imf, bs, cedge)
%
%  Inputs:  ims - Input Images (volume of gray images)
%           imf - Fused Image
%            bs - Block Size (default = 8)
%         cedge - Edge Coefficient (default = 0.2)
%
% Outputs:    q - Quality of the Fused Image. range [-1,1]
%         q_map - Quality Map of the Fused Image.
%
%

[r c n] = size(ims);

if (nargin == 1 | nargin > 4)
   quality = -Inf;
   quality_map = -1*ones(size(imf));
   return;
end

if [r c] ~= size(imf)
   quality = -Inf;
   quality_map = -1*ones(size(imf));
   return;
end

if nargin < 4
    cedge = 0.2;
end

if (nargin < 3)
   block_size = 8;
end

[quality, quality_map,s] = imqind(ims, imf, block_size);

s_sum=sum(s,3);
lambda=s./(s_sum(:,:,ones(1,n))+eps);

pw=1;
w=max(s,[],3);
sumw=sum(sum(w));
if sumw ~=0
    w=w./sum(sum(w));
    w=w.^pw;
end

quality_map=w.*sum(lambda.*quality_map,3);
quality = sum(quality_map(:));

if cedge ~=0
    [eims,aux]=sobel(ims);
    [eimf,aux]=sobel(imf);
    [equality, equality_map, s] = imqind(eims, eimf, block_size);

    s_sum=sum(s,3);
    lambda=s./(s_sum(:,:,ones(1,n))+eps);
    
    pw=1;
    w=max(s,[],3);
    sumw=sum(sum(w));
    if sumw ~=0
        w=w./sum(sum(w));
        w=w.^pw;
    end

    equality_map=w.*sum(lambda.*equality_map,3);
    equality = sum(equality_map(:));
    
    %for cedge = 0:.2:1    
    quality = quality ^ (1-cedge) * (equality ^ cedge);
end


