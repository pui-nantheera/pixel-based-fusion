function [quality, quality_map, s] = imqind(imi, imf, block_size)

[r c n] = size(imi);

N = block_size.^2;
sum2_filter = ones(block_size);

imi_sq = imi .* imi;
imf_sq = imf .* imf;
imif   = imi .* imf(:,:,ones(1,n)); %every input image is multiplied by the fused image

imi_sum    = convn(imi, sum2_filter, 'valid'); 
imf_sum    = convn(imf, sum2_filter, 'valid');
imi_sq_sum = convn(imi_sq, sum2_filter, 'valid');
imf_sq_sum = convn(imf_sq, sum2_filter, 'valid');
imif_sum   = convn(imif, sum2_filter, 'valid');

imif_sum_mul    = imi_sum.*imf_sum(:,:,ones(1,n));
imif_sq_sum_mul = imi_sum.*imi_sum + imf_sum(:,:,ones(1,n)).*imf_sum(:,:,ones(1,n));

numerator    = 4*(N*imif_sum - imif_sum_mul).*imif_sum_mul;
denominator1 = N*(imi_sq_sum + imf_sq_sum(:,:,ones(1,n))) - imif_sq_sum_mul;
denominator  = denominator1.*imif_sq_sum_mul;

quality_map = ones(size(denominator));
index = (denominator1 == 0) & (imif_sq_sum_mul ~= 0);
quality_map(index) = 2*imif_sum_mul(index)./(imif_sq_sum_mul(index)+eps);
index = (denominator ~= 0);

quality_map(index) = numerator(index)./(denominator(index)+eps);

quality = mean2(quality_map);

if nargout > 2
    s = imi_sq_sum/N - (imi_sum.*imi_sum)/N^2;
end