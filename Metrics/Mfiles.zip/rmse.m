function [y] = rmse(x1,x2)
%
%rmse.m,v 1.0 2002/02/06 18:01:40 
%===========================================================================
%               Eduardo Fernandez Canga - University of Bath
%
%                        Copyright (c) 2002
%===========================================================================
%
x1=double(x1(:));
x2=double(x2(:));
y=x1-x2;
y=sum(y.^2)/numel(y);
y=sqrt(y);


