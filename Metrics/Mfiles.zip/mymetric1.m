function r=mymetric1(ims)
%mymetric1.m, v 0.1 2003/12/07
% This is just a silly example... it calculates the means of the input
% images and returns a vector with them.
%
r=mean(mean(ims));