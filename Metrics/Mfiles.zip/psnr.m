function result = psnr(cleansignal,noisysignal)

if cleansignal == noisysignal
    result = Inf;
    return
end

result = 20 * log10 ( range([noisysignal(:);cleansignal(:)])  / rmse(cleansignal,noisysignal) );