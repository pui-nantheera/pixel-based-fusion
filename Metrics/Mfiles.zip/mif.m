function [mi,minorm]=mif(ims,imf)

if any(size(ims(:,:,1)) ~= size(imf))
    error('Wrong image size')
end
if max(ims)<=1
    ims = round(255*ims);
    imf = round(255*imf);
end

mi = 0;
minorm = 0;
for i = 1:size(ims,3)
    [mitemp,minormtemp]=mi_norm(ims(:,:,i),imf);
    mi     = mi     + mitemp;
    minorm = minorm + minormtemp;
end
mi     = mi     / size(ims,3);
minorm = minorm / size(ims,3);